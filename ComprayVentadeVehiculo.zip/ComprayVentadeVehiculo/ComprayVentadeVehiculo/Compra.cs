﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComprayVentadeVehiculo
{
    public partial class Compra : Form
    {
        public Compra()
        {
            InitializeComponent();
        }
        //VARIABLES GLOBALES
        int pos;
        int i = 1;
        int impuesto = 0;
        int total =0;
        int precio = 0;
        int cal_imp = 0;
        private void Calcu_imp()
        {
            impuesto = Convert.ToInt32(TxtImpuesto.Text);
            precio = Convert.ToInt32(TxtPrecio.Text);
            cal_imp = (precio * impuesto) / 100;
            total = precio + cal_imp;
            TxtTotal.Text = total.ToString();
            
        }
        private void Limpiar()
        {
            TxtNomComp.Text = "";
            TxtApeComp.Text = "";
            TxtDirComp.Text = "";
            TxtCedComp.Text = "";
            TxtTelComp.Text = "";
            CboMarca.Text = "";
            CboTipo.Text = "";
            TxtAño.Text = "";
            TxtColor.Text = "";
            CboCilindraje.Text = "";
            TxtMatricula.Text = "";
            TxtPrecio.Text = "";
            TxtTotal.Text = "";
            CboMarca.SelectedIndex = -1;
            TxtImpuesto.Text = null;
            CboTipo.SelectedIndex = -1;
            CboCilindraje.SelectedIndex = -1;
            CboTelComp.SelectedIndex = -1;
        }


        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA GUARDAR LA INFORMACION...?", "GUARDAR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                string nombre, apellido, direccion, cedula, telefono, marca, tipo, año
                    , color, cilindraje, n_matricula,precio,impuesto,total;
                //Datos para ingresar 
                nombre = TxtNomComp.Text;
                apellido = TxtApeComp.Text;
                direccion = TxtDirComp.Text;
                cedula = TxtCedComp.Text;
                telefono = TxtTelComp.Text;
                marca = CboMarca.Text;
                tipo = CboTipo.Text;
                año = TxtAño.Text;
                color = TxtColor.Text;
                cilindraje = CboCilindraje.Text;
                n_matricula = TxtMatricula.Text;
                precio = TxtPrecio.Text;
                impuesto = TxtImpuesto.Text;
                total = TxtTotal.Text;
                Dgv1.Rows.Add(i,nombre, apellido, direccion, cedula, telefono, marca, tipo, año
                    , color, cilindraje, n_matricula,precio,impuesto,total);
                i++;
                Calcu_imp();
                Limpiar();
                BtnAgregar.Enabled = false;
            }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA EDITAR LA INFORMACION...?", "EDITAR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Dgv1[1, pos].Value = TxtNomComp.Text;
                Dgv1[2, pos].Value = TxtApeComp.Text;
                Dgv1[3, pos].Value = TxtDirComp.Text;
                Dgv1[4, pos].Value = TxtCedComp.Text;
                Dgv1[5, pos].Value = TxtTelComp.Text;
                Dgv1[6, pos].Value = CboMarca.Text;
                Dgv1[7, pos].Value = CboTipo.Text;
                Dgv1[8, pos].Value = TxtAño.Text;
                Dgv1[9, pos].Value = TxtColor.Text;
                Dgv1[10, pos].Value = CboCilindraje.Text;
                Dgv1[11, pos].Value = TxtMatricula.Text;
                Dgv1[12, pos].Value = TxtPrecio.Text;
                Dgv1[13, pos].Value = TxtImpuesto.Text;
                Dgv1[14, pos].Value = TxtTotal.Text;
            }
        }

        private void Dgv1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos = Dgv1.CurrentRow.Index;
            TxtNomComp.Text = Dgv1[1, pos].Value.ToString();
            TxtApeComp.Text = Dgv1[2, pos].Value.ToString();
            TxtDirComp.Text = Dgv1[3, pos].Value.ToString();
            TxtCedComp.Text=Dgv1[4, pos].Value.ToString();
            TxtTelComp.Text=Dgv1[5, pos].Value.ToString();
            CboMarca.Text=Dgv1[6, pos].Value.ToString();
            CboTipo.Text=Dgv1[7, pos].Value.ToString();
            TxtAño.Text=Dgv1[8, pos].Value.ToString();
            TxtColor.Text=Dgv1[9, pos].Value.ToString();
            CboCilindraje.Text=Dgv1[10, pos].Value.ToString();
            TxtMatricula.Text = Dgv1[11, pos].Value.ToString();
            TxtPrecio.Text = Dgv1[12, pos].Value.ToString();
            TxtImpuesto.Text = Dgv1[13, pos].Value.ToString();
            TxtTotal.Text = Dgv1[14, pos].Value.ToString();
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("DESEA INGRESAR UN NUEVO DATO", "NUEVO DATO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Limpiar();
                BtnAgregar.Enabled = true;
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA ELIMINAR LA INFORMACION...?", "ELIMINAR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Dgv1.Rows.RemoveAt(pos);
                i--;
                Dgv1.Update();
            }
            
        }

        private void BtnRegresar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA REGRESAR AL MENU PRINCIPAL...?", "SALIR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void BtnElegir_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("DESEA INGRESAR FOTO DEL AUTO", "INGRESAR FOTO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                OpenFileDialog JORGE = new OpenFileDialog();

                JORGE.Filter = "ARCHIVOS DE IMAGEN(*.jpg)(*.jpeg) | *.jpg;*.jpeg";
                if (JORGE.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = JORGE.FileName;
                }
                else
                {
                    MessageBox.Show("NO SELECCIONO NINGUNA IMAGEN");
                }
            }
        }

        private void TxtApeComp_TextChanged(object sender, EventArgs e)
        {
            TxtApeComp.CharacterCasing = CharacterCasing.Upper;
        }

        private void TxtDirComp_TextChanged(object sender, EventArgs e)
        {
            TxtDirComp.CharacterCasing = CharacterCasing.Upper;
        }

        private void TxtNomComp_TextChanged(object sender, EventArgs e)
        {
            TxtNomComp.CharacterCasing = CharacterCasing.Upper;
        }

        private void TxtColor_TextChanged(object sender, EventArgs e)
        {
            TxtColor.CharacterCasing = CharacterCasing.Upper;
        }

        private void CboTelComp_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CboTelComp.SelectedIndex == 0)
            {
                TxtTelComp.MaxLength = 9;
            }
            if (CboTelComp.SelectedIndex == 1)
            {
                TxtTelComp.MaxLength = 10;
            }
        }

        private void TxtCedComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtTelComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtImpuesto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtAño_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtNomComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtColor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtTelComp_TextChanged(object sender, EventArgs e)
        {
            if (TxtTelComp.TextLength > 0) 
            {
                CboTelComp.Enabled = false;
            }
            else
            {
                CboTelComp.Enabled = true;
            }
        }

        private void TxtMatricula_TextChanged(object sender, EventArgs e)
        {
            TxtMatricula.CharacterCasing = CharacterCasing.Upper;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Calcu_imp();
            BtnAgregar.Enabled = true;
        }
    }
}

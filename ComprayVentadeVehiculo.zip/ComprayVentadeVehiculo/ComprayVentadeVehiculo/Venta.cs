﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComprayVentadeVehiculo
{
    public partial class Venta : Form
    {
        public Venta()
        {
            InitializeComponent();
        }
        int pos;
        int i = 1;
        int impuesto = 0;
        double total = 0;
        int precio = 0;
        int cal_imp = 0;
        int numTr, mesTr, aTr, ccvTr;
        bool Control ; // Este valor permitira controlar si el tipo de pago seleccionado sea EFECTIVO para acceder al metodo CalcImp.(GROUPBOX4)

        FormPago frPago = new FormPago();
        Credit Credito = new Credit();
        private void Calcu_imp()
        {
            //int.TryParse(TxtImpuesto.Text, out impuesto);
            impuesto = Convert.ToInt32(TxtImpuesto.Text);
            precio = Convert.ToInt32(TxtPrecio.Text);
            cal_imp = (precio * impuesto) / 100;
            total = precio + cal_imp;
            TxtTotal.Text = total.ToString();

        }
        private void Limpiar()
        {
            TxtNomVen.Text = "";
            TxtApeVen.Text = "";
            TxtDirVen.Text = "";
            TxttCedVen.Text = "";
            TxtTelVen.Text = "";
            TxtImpuesto.Text = null;
            CboMarca.Text = "";
            CboMarca.SelectedIndex = -1;
            CboTipo.Text = "";
            CboTipo.SelectedIndex = -1;
            TxtAño.Text = "";
            TxtColor.Text = "";
            CboCilindraje.Text = "";
            CboCilindraje.SelectedIndex = -1;
            TxtMatricula.Text = "";
            TxtPrecio.Text = "";
            TxtTotal.Text = "";
            CboTelVen.SelectedIndex = -1;
            cboPago.SelectedIndex = -1;
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA GUARDAR LA INFORMACION...?", "GUARDAR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                string nombre, apellido, direccion, cedula, telefono, marca, tipo, año
                    , color, cilindraje, n_matricula,precio,impuesto,total,tipoPag;
                //Datos para ingresar 
                nombre = TxtNomVen.Text;
                apellido = TxtApeVen.Text;
                direccion = TxtDirVen.Text;
                cedula = TxttCedVen.Text;
                telefono = TxtTelVen.Text;
                marca = CboMarca.Text;
                tipo = CboTipo.Text;
                año = TxtAño.Text;
                color = TxtColor.Text;
                cilindraje = CboCilindraje.Text;
                n_matricula = TxtMatricula.Text;
                if (TxtPrecio.TextLength>1) // Validacion si el valor del precio es en efectivo o a Credito(Campos similar al group box creado en el Formulario Ventas)
                {
                    precio = TxtPrecio.Text;
                }
                else
                {
                    precio = Credito.ValrVehi;
                }
                impuesto = TxtImpuesto.Text;
                if (TxtTotal.TextLength>1)
                {
                    total = TxtTotal.Text;
                }
                else
                {
                    total = Credito.Cuotas;
                }
                tipoPag = cboPago.Text;
                Dgv1.Rows.Add(i, nombre, apellido, direccion, cedula, telefono, marca, tipo, año
                    , color, cilindraje, n_matricula,precio, impuesto, total,tipoPag, numTr,aTr);
                i++;
                if (Control)
                {
                    Calcu_imp();
                }
                Limpiar();
                BtnAgregar.Enabled = false;
            }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA EDITAR LA INFORMACION...?", "EDITAR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Dgv1[1, pos].Value = TxtNomVen.Text;
                Dgv1[2, pos].Value = TxtApeVen.Text;
                Dgv1[3, pos].Value = TxtDirVen.Text;
                Dgv1[4, pos].Value = TxttCedVen.Text;
                Dgv1[5, pos].Value = TxtTelVen.Text;
                Dgv1[6, pos].Value = CboMarca.Text;
                Dgv1[7, pos].Value = CboTipo.Text;
                Dgv1[8, pos].Value = TxtAño.Text;
                Dgv1[9, pos].Value = TxtColor.Text;
                Dgv1[10, pos].Value = CboCilindraje.Text;
                Dgv1[11, pos].Value = TxtMatricula.Text;
                Dgv1[12, pos].Value = TxtPrecio.Text;
                Dgv1[13, pos].Value = TxtImpuesto.Text;
                Dgv1[14, pos].Value = TxtTotal.Text;
                Dgv1[15, pos].Value = cboPago.Text;
                Dgv1[16, pos].Value = frPago.NumTarjeta;
                Dgv1[17, pos].Value = frPago.AñoTarjeta;
                Dgv1[18, pos].Value = Credito.Cuotas;
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA ELIMINAR LA INFORMACION...?", "ELIMINAR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Dgv1.Rows.RemoveAt(pos);
                i--;
                Dgv1.Update();
            }
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("DESEA INGRESAR UN NUEVO DATO", "NUEVO DATO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Limpiar();
                BtnAgregar.Enabled = true;
            }
        }

        private void BtnRegresar_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(" DESEA REGRESAR AL MENU PRINCIPAL...?", "SALIR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void BtnElegir_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("DESEA INGRESAR FOTO DEL AUTO", "INGRESAR FOTO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                OpenFileDialog JORGE = new OpenFileDialog();

                JORGE.Filter = "ARCHIVOS DE IMAGEN(*.jpg)(*.jpeg) | *.jpg;*.jpeg";
                if (JORGE.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = JORGE.FileName;
                }
                else
                {
                    MessageBox.Show("NO SELECCIONO NINGUNA IMAGEN");
                }
            }
        }

        private void Dgv1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos = Dgv1.CurrentRow.Index;
            TxtNomVen.Text = Dgv1[1, pos].Value.ToString();
            TxtApeVen.Text = Dgv1[2, pos].Value.ToString();
            TxtDirVen.Text = Dgv1[3, pos].Value.ToString();
            TxttCedVen.Text = Dgv1[4, pos].Value.ToString();
            TxtTelVen.Text = Dgv1[5, pos].Value.ToString();
            CboMarca.Text = Dgv1[6, pos].Value.ToString();
            CboTipo.Text = Dgv1[7, pos].Value.ToString();
            TxtAño.Text = Dgv1[8, pos].Value.ToString();
            TxtColor.Text = Dgv1[9, pos].Value.ToString();
            CboCilindraje.Text = Dgv1[10, pos].Value.ToString();
            TxtMatricula.Text = Dgv1[11, pos].Value.ToString();
            TxtPrecio.Text = Dgv1[12, pos].Value.ToString();
            TxtImpuesto.Text = Dgv1[13, pos].Value.ToString();
            TxtTotal.Text = Dgv1[14, pos].Value.ToString();
            cboPago.Text = Dgv1[15, pos].Value.ToString();
            frPago.NumTarjeta = Dgv1[16, pos].Value.ToString();
            frPago.AñoTarjeta = Dgv1[17, pos].Value.ToString();
            Credito.Cuotas = Dgv1[18, pos].Value.ToString();
        }

        private void TxtApeVen_TextChanged(object sender, EventArgs e)
        {
            TxtApeVen.CharacterCasing = CharacterCasing.Upper;
        }

        private void TxtDirVen_TextChanged(object sender, EventArgs e)
        {
            TxtDirVen.CharacterCasing = CharacterCasing.Upper;
        }

        private void TxtNomVen_TextChanged(object sender, EventArgs e)
        {
            TxtNomVen.CharacterCasing = CharacterCasing.Upper;
        }

        private void TxtColor_TextChanged(object sender, EventArgs e)
        {
            TxtColor.CharacterCasing = CharacterCasing.Upper;
        }

        private void CboTelVen_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CboTelVen.SelectedIndex == 0)
            {
                TxtTelVen.MaxLength = 9;
            }
            if (CboTelVen.SelectedIndex ==1)
            {
                TxtTelVen.MaxLength = 10;
            }
        }

        private void TxtMatricula_TextChanged(object sender, EventArgs e)
        {
            TxtMatricula.CharacterCasing = CharacterCasing.Upper;
        }

        private void TxtApeVen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtColor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxttCedVen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtTelVen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtImpuesto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TxtAño_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnGuardrPago_Click(object sender, EventArgs e)
        {
            BtnAgregar.Enabled = true;
        }

        private void TxtImpuesto_TextChanged(object sender, EventArgs e)
        {
            if (TxtImpuesto.TextLength > 0)
            {
                btnCalcular.Enabled = true;
            }
            else
            {
                btnCalcular.Enabled = false;
            }
        }

        private void TxtPrecio_TextChanged(object sender, EventArgs e)
        {
            if (TxtPrecio.TextLength > 0)
            {
                TxtImpuesto.Enabled = true;
                cboPago.Enabled = false;
            }
            else
            {
                cboPago.Enabled = true;
                TxtImpuesto.Enabled = false;
                btnCalcular.Enabled = false;
            }
        }

        private void TxtTelVen_TextChanged(object sender, EventArgs e)
        {
            if (TxtTelVen.TextLength > 0)
            {
                CboTelVen.Enabled = false;
            }
            else
            {
                CboTelVen.Enabled = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Calcu_imp();
            BtnAgregar.Enabled = true;
        }

        private void cboPago_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (cboPago.SelectedIndex == 0)
            {
                groupBox4.Enabled = false;
                frPago.ShowDialog();
                if (frPago.DialogResult == DialogResult.OK)
                {
                    Int32.TryParse(frPago.NumTarjeta, out numTr);
                    Int32.TryParse(frPago.MesTarjeta, out mesTr);
                    Int32.TryParse(frPago.AñoTarjeta, out aTr);
                    Int32.TryParse(frPago.CCVTarjeta, out ccvTr);
                }
                btnGuardrPago.Enabled = true;
                Control = false;
            }
            else
            {
                if (cboPago.SelectedIndex == 1)
                {
                    groupBox4.Enabled = false;
                    frPago.ShowDialog();
                    if (frPago.DialogResult == DialogResult.OK)
                    {
                        Int32.TryParse(frPago.NumTarjeta, out numTr);
                        Int32.TryParse(frPago.MesTarjeta, out mesTr);
                        Int32.TryParse(frPago.AñoTarjeta, out aTr);
                        Int32.TryParse(frPago.CCVTarjeta, out ccvTr);
                    }
                    btnGuardrPago.Enabled = true;
                    Control = false;
                }
                else
                {
                    if (cboPago.SelectedIndex == 2)
                    {
                        groupBox4.Enabled = false;
                        frPago.ShowDialog();
                        if (frPago.DialogResult == DialogResult.OK)
                        {
                            Int32.TryParse(frPago.NumTarjeta, out numTr);
                            Int32.TryParse(frPago.MesTarjeta, out mesTr);
                            Int32.TryParse(frPago.AñoTarjeta, out aTr);
                            Int32.TryParse(frPago.CCVTarjeta, out ccvTr);
                        }
                        btnGuardrPago.Enabled = true;
                        Control = false;
                    }
                    else
                    {
                        if (cboPago.SelectedIndex == 3)
                        {
                            Credito.ShowDialog();
                            if (Credito.DialogResult == DialogResult.OK)
                            {
                                precio = Convert.ToInt32(Credito.ValrVehi);
                                total = Convert.ToInt32(Credito.Cuotas);
                            }
                            btnGuardrPago.Enabled = true;
                            Control = false;
                        }
                        else
                        {
                            if (cboPago.SelectedIndex == 4)
                            {
                                btnGuardrPago.Enabled = false;
                                groupBox4.Enabled = true;
                                Control = true;
                            }
                            else
                            {
                                groupBox4.Enabled = false;
                            }
                        }
                    }
                }
            } // Fin Seleccion de Items Tipo Pago
        }
    }
}

﻿namespace ComprayVentadeVehiculo
{
    partial class Venta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.CboMarca = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TxtTelVen = new System.Windows.Forms.TextBox();
            this.TxttCedVen = new System.Windows.Forms.TextBox();
            this.TxtDirVen = new System.Windows.Forms.TextBox();
            this.TxtApeVen = new System.Windows.Forms.TextBox();
            this.TxtNomVen = new System.Windows.Forms.TextBox();
            this.CboTelVen = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.TxtColor = new System.Windows.Forms.TextBox();
            this.CboCilindraje = new System.Windows.Forms.ComboBox();
            this.TxtAño = new System.Windows.Forms.TextBox();
            this.CboTipo = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.TxtTotal = new System.Windows.Forms.TextBox();
            this.TxtImpuesto = new System.Windows.Forms.TextBox();
            this.TxtPrecio = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.Dgv1 = new System.Windows.Forms.DataGridView();
            this.label23 = new System.Windows.Forms.Label();
            this.BtnAgregar = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.BtnNuevo = new System.Windows.Forms.Button();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.BtnElegir = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnGuardrPago = new System.Windows.Forms.Button();
            this.cboPago = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(389, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "FORMULARIO DE VENTA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 286);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "TELEFONO: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 123);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "APELLIDO:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 68);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "NOMBRE:\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 231);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "CEDULA:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 178);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "DIRECCIÓN:";
            // 
            // CboMarca
            // 
            this.CboMarca.FormattingEnabled = true;
            this.CboMarca.Items.AddRange(new object[] {
            "HYUNDAI",
            "CHEVROLET",
            "KIA",
            "NISSAN",
            "OTRO"});
            this.CboMarca.Location = new System.Drawing.Point(135, 68);
            this.CboMarca.Margin = new System.Windows.Forms.Padding(4);
            this.CboMarca.Name = "CboMarca";
            this.CboMarca.Size = new System.Drawing.Size(160, 24);
            this.CboMarca.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TxtTelVen);
            this.groupBox1.Controls.Add(this.TxttCedVen);
            this.groupBox1.Controls.Add(this.TxtDirVen);
            this.groupBox1.Controls.Add(this.TxtApeVen);
            this.groupBox1.Controls.Add(this.TxtNomVen);
            this.groupBox1.Controls.Add(this.CboTelVen);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(16, 62);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(397, 326);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DATOS DEL COMPRADOR";
            // 
            // TxtTelVen
            // 
            this.TxtTelVen.Location = new System.Drawing.Point(241, 276);
            this.TxtTelVen.Margin = new System.Windows.Forms.Padding(4);
            this.TxtTelVen.Name = "TxtTelVen";
            this.TxtTelVen.Size = new System.Drawing.Size(132, 22);
            this.TxtTelVen.TabIndex = 18;
            this.TxtTelVen.TextChanged += new System.EventHandler(this.TxtTelVen_TextChanged);
            this.TxtTelVen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTelVen_KeyPress);
            // 
            // TxttCedVen
            // 
            this.TxttCedVen.Location = new System.Drawing.Point(109, 228);
            this.TxttCedVen.Margin = new System.Windows.Forms.Padding(4);
            this.TxttCedVen.MaxLength = 10;
            this.TxttCedVen.Name = "TxttCedVen";
            this.TxttCedVen.Size = new System.Drawing.Size(132, 22);
            this.TxttCedVen.TabIndex = 17;
            this.TxttCedVen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxttCedVen_KeyPress);
            // 
            // TxtDirVen
            // 
            this.TxtDirVen.Location = new System.Drawing.Point(109, 170);
            this.TxtDirVen.Margin = new System.Windows.Forms.Padding(4);
            this.TxtDirVen.MaxLength = 22;
            this.TxtDirVen.Name = "TxtDirVen";
            this.TxtDirVen.Size = new System.Drawing.Size(132, 22);
            this.TxtDirVen.TabIndex = 16;
            this.TxtDirVen.TextChanged += new System.EventHandler(this.TxtDirVen_TextChanged);
            // 
            // TxtApeVen
            // 
            this.TxtApeVen.Location = new System.Drawing.Point(109, 113);
            this.TxtApeVen.Margin = new System.Windows.Forms.Padding(4);
            this.TxtApeVen.MaxLength = 22;
            this.TxtApeVen.Name = "TxtApeVen";
            this.TxtApeVen.Size = new System.Drawing.Size(132, 22);
            this.TxtApeVen.TabIndex = 15;
            this.TxtApeVen.TextChanged += new System.EventHandler(this.TxtApeVen_TextChanged);
            this.TxtApeVen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtApeVen_KeyPress);
            // 
            // TxtNomVen
            // 
            this.TxtNomVen.Location = new System.Drawing.Point(109, 59);
            this.TxtNomVen.Margin = new System.Windows.Forms.Padding(4);
            this.TxtNomVen.MaxLength = 22;
            this.TxtNomVen.Name = "TxtNomVen";
            this.TxtNomVen.Size = new System.Drawing.Size(132, 22);
            this.TxtNomVen.TabIndex = 14;
            this.TxtNomVen.TextChanged += new System.EventHandler(this.TxtNomVen_TextChanged);
            this.TxtNomVen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtApeVen_KeyPress);
            // 
            // CboTelVen
            // 
            this.CboTelVen.FormattingEnabled = true;
            this.CboTelVen.Items.AddRange(new object[] {
            "FIJO",
            "MOVIL"});
            this.CboTelVen.Location = new System.Drawing.Point(109, 276);
            this.CboTelVen.Margin = new System.Windows.Forms.Padding(4);
            this.CboTelVen.Name = "CboTelVen";
            this.CboTelVen.Size = new System.Drawing.Size(111, 24);
            this.CboTelVen.TabIndex = 11;
            this.CboTelVen.SelectedIndexChanged += new System.EventHandler(this.CboTelVen_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TxtMatricula);
            this.groupBox2.Controls.Add(this.TxtColor);
            this.groupBox2.Controls.Add(this.CboCilindraje);
            this.groupBox2.Controls.Add(this.TxtAño);
            this.groupBox2.Controls.Add(this.CboTipo);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.CboMarca);
            this.groupBox2.Location = new System.Drawing.Point(445, 62);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(363, 369);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DATOS DEL VEHICULO";
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(135, 321);
            this.TxtMatricula.Margin = new System.Windows.Forms.Padding(4);
            this.TxtMatricula.MaxLength = 7;
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(132, 22);
            this.TxtMatricula.TabIndex = 23;
            this.TxtMatricula.TextChanged += new System.EventHandler(this.TxtMatricula_TextChanged);
            // 
            // TxtColor
            // 
            this.TxtColor.Location = new System.Drawing.Point(135, 223);
            this.TxtColor.Margin = new System.Windows.Forms.Padding(4);
            this.TxtColor.MaxLength = 10;
            this.TxtColor.Name = "TxtColor";
            this.TxtColor.Size = new System.Drawing.Size(132, 22);
            this.TxtColor.TabIndex = 22;
            this.TxtColor.TextChanged += new System.EventHandler(this.TxtColor_TextChanged);
            this.TxtColor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtColor_KeyPress);
            // 
            // CboCilindraje
            // 
            this.CboCilindraje.FormattingEnabled = true;
            this.CboCilindraje.Items.AddRange(new object[] {
            "1.2",
            "1.4",
            "1.6",
            "1.8",
            "2.0"});
            this.CboCilindraje.Location = new System.Drawing.Point(135, 276);
            this.CboCilindraje.Margin = new System.Windows.Forms.Padding(4);
            this.CboCilindraje.Name = "CboCilindraje";
            this.CboCilindraje.Size = new System.Drawing.Size(160, 24);
            this.CboCilindraje.TabIndex = 21;
            // 
            // TxtAño
            // 
            this.TxtAño.Location = new System.Drawing.Point(135, 175);
            this.TxtAño.Margin = new System.Windows.Forms.Padding(4);
            this.TxtAño.MaxLength = 4;
            this.TxtAño.Name = "TxtAño";
            this.TxtAño.Size = new System.Drawing.Size(132, 22);
            this.TxtAño.TabIndex = 20;
            this.TxtAño.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtAño_KeyPress);
            // 
            // CboTipo
            // 
            this.CboTipo.FormattingEnabled = true;
            this.CboTipo.Items.AddRange(new object[] {
            "SEDAN",
            "CAMIONETA"});
            this.CboTipo.Location = new System.Drawing.Point(135, 113);
            this.CboTipo.Margin = new System.Windows.Forms.Padding(4);
            this.CboTipo.Name = "CboTipo";
            this.CboTipo.Size = new System.Drawing.Size(160, 24);
            this.CboTipo.TabIndex = 19;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 286);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 17);
            this.label17.TabIndex = 15;
            this.label17.Text = "CILINDRAJE:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 231);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 17);
            this.label16.TabIndex = 14;
            this.label16.Text = "COLOR";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 178);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 17);
            this.label15.TabIndex = 13;
            this.label15.Text = "AÑO:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 123);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 17);
            this.label14.TabIndex = 12;
            this.label14.Text = "TIPO:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 331);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 17);
            this.label12.TabIndex = 10;
            this.label12.Text = "N° MATRICULA:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 68);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 17);
            this.label13.TabIndex = 11;
            this.label13.Text = "MARCA:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.TxtTotal);
            this.groupBox4.Controls.Add(this.TxtImpuesto);
            this.groupBox4.Controls.Add(this.TxtPrecio);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Enabled = false;
            this.groupBox4.Location = new System.Drawing.Point(16, 407);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(325, 113);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "VALOR A PAGAR";
            // 
            // TxtTotal
            // 
            this.TxtTotal.Enabled = false;
            this.TxtTotal.Location = new System.Drawing.Point(168, 76);
            this.TxtTotal.Margin = new System.Windows.Forms.Padding(4);
            this.TxtTotal.Name = "TxtTotal";
            this.TxtTotal.Size = new System.Drawing.Size(132, 22);
            this.TxtTotal.TabIndex = 9;
            this.TxtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtImpuesto
            // 
            this.TxtImpuesto.Location = new System.Drawing.Point(168, 46);
            this.TxtImpuesto.Margin = new System.Windows.Forms.Padding(4);
            this.TxtImpuesto.MaxLength = 2;
            this.TxtImpuesto.Name = "TxtImpuesto";
            this.TxtImpuesto.Size = new System.Drawing.Size(132, 22);
            this.TxtImpuesto.TabIndex = 8;
            this.TxtImpuesto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtImpuesto.TextChanged += new System.EventHandler(this.TxtImpuesto_TextChanged);
            this.TxtImpuesto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtImpuesto_KeyPress);
            // 
            // TxtPrecio
            // 
            this.TxtPrecio.Location = new System.Drawing.Point(168, 16);
            this.TxtPrecio.Margin = new System.Windows.Forms.Padding(4);
            this.TxtPrecio.MaxLength = 6;
            this.TxtPrecio.Name = "TxtPrecio";
            this.TxtPrecio.Size = new System.Drawing.Size(132, 22);
            this.TxtPrecio.TabIndex = 7;
            this.TxtPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtPrecio.TextChanged += new System.EventHandler(this.TxtPrecio_TextChanged);
            this.TxtPrecio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtImpuesto_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 85);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(123, 17);
            this.label20.TabIndex = 6;
            this.label20.Text = "TOTAL A PAGAR:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 53);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 17);
            this.label18.TabIndex = 5;
            this.label18.Text = "IMPUESTO:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(301, 36);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 17);
            this.label22.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 25);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(63, 17);
            this.label19.TabIndex = 1;
            this.label19.Text = "PRECIO:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1253, 124);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 17);
            this.label21.TabIndex = 13;
            this.label21.Text = "VEHICULO";
            // 
            // Dgv1
            // 
            this.Dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18});
            this.Dgv1.Location = new System.Drawing.Point(16, 588);
            this.Dgv1.Margin = new System.Windows.Forms.Padding(4);
            this.Dgv1.Name = "Dgv1";
            this.Dgv1.Size = new System.Drawing.Size(1484, 114);
            this.Dgv1.TabIndex = 14;
            this.Dgv1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv1_CellClick);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(231, 540);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(754, 29);
            this.label23.TabIndex = 15;
            this.label23.Text = "TABLA CON LOS DATOS DEL COMPRADOR Y DEL VEHICULO";
            // 
            // BtnAgregar
            // 
            this.BtnAgregar.Enabled = false;
            this.BtnAgregar.Location = new System.Drawing.Point(217, 710);
            this.BtnAgregar.Margin = new System.Windows.Forms.Padding(4);
            this.BtnAgregar.Name = "BtnAgregar";
            this.BtnAgregar.Size = new System.Drawing.Size(100, 39);
            this.BtnAgregar.TabIndex = 16;
            this.BtnAgregar.Text = "AGREGAR";
            this.BtnAgregar.UseVisualStyleBackColor = true;
            this.BtnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // BtnEditar
            // 
            this.BtnEditar.Location = new System.Drawing.Point(364, 710);
            this.BtnEditar.Margin = new System.Windows.Forms.Padding(4);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(100, 39);
            this.BtnEditar.TabIndex = 17;
            this.BtnEditar.Text = "EDITAR";
            this.BtnEditar.UseVisualStyleBackColor = true;
            this.BtnEditar.Click += new System.EventHandler(this.BtnEditar_Click);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Location = new System.Drawing.Point(541, 710);
            this.BtnEliminar.Margin = new System.Windows.Forms.Padding(4);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(100, 39);
            this.BtnEliminar.TabIndex = 18;
            this.BtnEliminar.Text = "ELIMINAR";
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // BtnNuevo
            // 
            this.BtnNuevo.Location = new System.Drawing.Point(752, 710);
            this.BtnNuevo.Margin = new System.Windows.Forms.Padding(4);
            this.BtnNuevo.Name = "BtnNuevo";
            this.BtnNuevo.Size = new System.Drawing.Size(100, 39);
            this.BtnNuevo.TabIndex = 19;
            this.BtnNuevo.Text = "NUEVO";
            this.BtnNuevo.UseVisualStyleBackColor = true;
            this.BtnNuevo.Click += new System.EventHandler(this.BtnNuevo_Click);
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.Location = new System.Drawing.Point(1176, 710);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(4);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(100, 46);
            this.BtnRegresar.TabIndex = 20;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = true;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // BtnElegir
            // 
            this.BtnElegir.Location = new System.Drawing.Point(1219, 398);
            this.BtnElegir.Margin = new System.Windows.Forms.Padding(4);
            this.BtnElegir.Name = "BtnElegir";
            this.BtnElegir.Size = new System.Drawing.Size(163, 48);
            this.BtnElegir.TabIndex = 21;
            this.BtnElegir.Text = "ELEGIR";
            this.BtnElegir.UseVisualStyleBackColor = true;
            this.BtnElegir.Click += new System.EventHandler(this.BtnElegir_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Enabled = false;
            this.btnCalcular.Location = new System.Drawing.Point(394, 455);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(149, 50);
            this.btnCalcular.TabIndex = 38;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnGuardrPago);
            this.groupBox3.Controls.Add(this.cboPago);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(855, 121);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(241, 277);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "FORMAS DE PAGO";
            // 
            // btnGuardrPago
            // 
            this.btnGuardrPago.Location = new System.Drawing.Point(43, 191);
            this.btnGuardrPago.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuardrPago.Name = "btnGuardrPago";
            this.btnGuardrPago.Size = new System.Drawing.Size(163, 48);
            this.btnGuardrPago.TabIndex = 40;
            this.btnGuardrPago.Text = "GUARDAR";
            this.btnGuardrPago.UseVisualStyleBackColor = true;
            this.btnGuardrPago.Click += new System.EventHandler(this.btnGuardrPago_Click);
            // 
            // cboPago
            // 
            this.cboPago.FormattingEnabled = true;
            this.cboPago.Items.AddRange(new object[] {
            "VISA ",
            "MASTERCARD",
            "TARJETA DE DEBITO",
            "CREDITO (PLAZO HASTA 5 AÑOS)",
            "EFECTIVO"});
            this.cboPago.Location = new System.Drawing.Point(46, 109);
            this.cboPago.Margin = new System.Windows.Forms.Padding(4);
            this.cboPago.Name = "cboPago";
            this.cboPago.Size = new System.Drawing.Size(160, 24);
            this.cboPago.TabIndex = 24;
            this.cboPago.SelectedIndexChanged += new System.EventHandler(this.cboPago_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(26, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 55);
            this.label5.TabIndex = 0;
            this.label5.Text = "Elige la forma de pago que el cliente desea realizar.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "# venta";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "NOMBRE";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "APELLIDO";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "DIRECCION";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "CEDULA";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "TELEFONO";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "MARCA";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "TIPO";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "AÑO";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "COLOR";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "CILINDRAJE";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "MATRICULA";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "PRECIO";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.HeaderText = "VLR IMPUESTO";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.HeaderText = "VALOR TOTAL";
            this.Column15.Name = "Column15";
            // 
            // Column16
            // 
            this.Column16.HeaderText = "TIPO DE PAGO";
            this.Column16.Name = "Column16";
            // 
            // Column17
            // 
            this.Column17.HeaderText = "NRO. TARJETA";
            this.Column17.Name = "Column17";
            // 
            // Column18
            // 
            this.Column18.HeaderText = "AÑO VALIDO";
            this.Column18.Name = "Column18";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1148, 144);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(291, 246);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Venta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1513, 761);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.BtnElegir);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.BtnNuevo);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnAgregar);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.Dgv1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Venta";
            this.ShowIcon = false;
            this.Text = "Venta";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox CboMarca;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox CboTipo;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TxtAño;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.TextBox TxtColor;
        private System.Windows.Forms.ComboBox CboCilindraje;
        private System.Windows.Forms.TextBox TxttCedVen;
        private System.Windows.Forms.TextBox TxtDirVen;
        private System.Windows.Forms.TextBox TxtApeVen;
        private System.Windows.Forms.TextBox TxtNomVen;
        private System.Windows.Forms.ComboBox CboTelVen;
        private System.Windows.Forms.TextBox TxtTelVen;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox TxtTotal;
        private System.Windows.Forms.TextBox TxtImpuesto;
        private System.Windows.Forms.TextBox TxtPrecio;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView Dgv1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button BtnAgregar;
        private System.Windows.Forms.Button BtnEditar;
        private System.Windows.Forms.Button BtnEliminar;
        private System.Windows.Forms.Button BtnNuevo;
        private System.Windows.Forms.Button BtnRegresar;
        private System.Windows.Forms.Button BtnElegir;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnGuardrPago;
        private System.Windows.Forms.ComboBox cboPago;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComprayVentadeVehiculo
{
    public partial class FormPago : Form
    {
        public FormPago()
        {
            InitializeComponent();
        }

        // Variables de tipo private 
        private string num;
        private string mes;
        private string año;
        private string ccv;

        public string NumTarjeta
        {
            get { return num; }
            set { num = value; }
        }

        public string MesTarjeta
        {
            get { return mes; }
            set { mes = value; }
        }
        public string AñoTarjeta
        {
            get { return año; }
            set { año = value; }
        }
        public string CCVTarjeta
        {
            get { return ccv; }
            set { ccv = value; }
        }
        //
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter (e.KeyChar))
            {
                e.Handled = true;
            }
            num = nroTarjet.Text; 
        }

        private void textBox1_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter (e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void FormPago_Load(object sender, EventArgs e)
        {
            // No UTILIZAR
        }

        private void cboMes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboMes.SelectedIndex > -1)
            {
                nroTarjet.Enabled = false;
                mes = cboMes.SelectedItem.ToString();
                cboAño.Enabled = true;
                //cboAño.Focus();
                
            }
            else
            {
                nroTarjet.Enabled = true;
            }
        }

        private void cboAño_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboAño.SelectedIndex > -1)
            {
                cboMes.Enabled = false;
                año = cboAño.SelectedItem.ToString();
                txtCCV.Enabled = true;
                txtCCV.Focus();
            }
            
        }

        private void txtCCV_TextChanged(object sender, EventArgs e)
        {
            if (txtCCV.TextLength >= 2)
            {
                cboAño.Enabled = false;
                cboMes.Enabled = false;
                nroTarjet.Enabled = false;
                ccv = txtCCV.Text;
                btnSaveTr.Enabled = true;
            }
            else
            {
                if (txtCCV.TextLength == 0)
                {
                    cboAño.Enabled = true;
                    cboMes.Enabled = true;
                    nroTarjet.Enabled = true;
                }
            }
            
        }

        private void nroTarjet_TextChanged(object sender, EventArgs e)
        {
            if (nroTarjet.TextLength > 13)
            {
                cboMes.Enabled = true;
                //cboMes.Focus();
            }
            else
            {
                if (nroTarjet.TextLength ==-1)
                {
                    cboMes.Enabled = false;
                    cboMes.SelectedItem = -1;
                }        
            }
        }

        private void btnSaveTr_Click(object sender, EventArgs e)
        {
            txtCCV.Enabled = false;
            num = nroTarjet.Text;
            mes = cboMes.Text;
            año = cboAño.Text;
            ccv = txtCCV.Text;
        }

        internal string Show(string numTarjeta)
        {
            throw new NotImplementedException();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComprayVentadeVehiculo
{
    public partial class Credit : Form
    {
        public Credit()
        {
            InitializeComponent();
        }
        double vlrV,iva = 0.12,vlrCuot;
        int anPl,diasPl;

        private string vlrVeh;
        private string anPlazo;
        private string cuotas;
        public string ValrVehi
        {
            get { return vlrVeh; }
            set { vlrVeh = value; }
        }
        public string AnPlazo
        {
            get { return anPlazo; }
            set { anPlazo = value; }
        }
        public string Cuotas
        {
            get { return cuotas; }
            set { cuotas = value; }
        }
        private void btnPresupuest_Click(object sender, EventArgs e)
        {
            Presupuesto();
            btnAceptrVlr.Enabled = true;
            btnClean.Enabled = true;
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            foreach (Control txt in this.Controls)
            {
                if (txt is TextBox)
                {
                    txt.Text = string.Empty;
                }
            }
            vlrV = 0;
            vlrCuot = 0;
            anPl = 0;
            diasPl = 0;
            btnAceptrVlr.Enabled = false;
            btnPresupuest.Enabled = false;
            btnClean.Enabled = false;
        }

        private void btnAceptrVlr_Click(object sender, EventArgs e)
        {
            ValrVehi = vlrV.ToString();
            AnPlazo = anPl.ToString();
            Cuotas = vlrCuot.ToString();
        }

        private void txtPlazPag_TextChanged(object sender, EventArgs e)
        {
            if (txtPlazPag.TextLength>0)
            {
                btnPresupuest.Enabled = true;
            }
            else
            {
                btnPresupuest.Enabled = false;
            }
        }

        private void txtVlrV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // metodo para calcular el presupuesto.
        private void Presupuesto()
        {
            vlrV = Convert.ToDouble(txtVlrV.Text);
            anPl = Convert.ToInt32(txtPlazPag.Text);
            diasPl = anPl * 30;
            vlrCuot = (vlrV + (vlrV * 0.12)) / diasPl;
            txtCuotas.Text = vlrCuot.ToString();
        }
    }
}

﻿namespace ComprayVentadeVehiculo
{
    partial class Compra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnElegir = new System.Windows.Forms.Button();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.BtnNuevo = new System.Windows.Forms.Button();
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnAgregar = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.Dgv1 = new System.Windows.Forms.DataGridView();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.TxtTotal = new System.Windows.Forms.TextBox();
            this.TxtImpuesto = new System.Windows.Forms.TextBox();
            this.TxtPrecio = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TxtTelComp = new System.Windows.Forms.TextBox();
            this.TxtCedComp = new System.Windows.Forms.TextBox();
            this.TxtNomComp = new System.Windows.Forms.TextBox();
            this.CboTelComp = new System.Windows.Forms.ComboBox();
            this.TxtDirComp = new System.Windows.Forms.TextBox();
            this.TxtApeComp = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.TxtColor = new System.Windows.Forms.TextBox();
            this.CboCilindraje = new System.Windows.Forms.ComboBox();
            this.TxtAño = new System.Windows.Forms.TextBox();
            this.CboTipo = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.CboMarca = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnElegir
            // 
            this.BtnElegir.Location = new System.Drawing.Point(903, 357);
            this.BtnElegir.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnElegir.Name = "BtnElegir";
            this.BtnElegir.Size = new System.Drawing.Size(163, 48);
            this.BtnElegir.TabIndex = 36;
            this.BtnElegir.Text = "ELEGIR";
            this.BtnElegir.UseVisualStyleBackColor = true;
            this.BtnElegir.Click += new System.EventHandler(this.BtnElegir_Click);
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.Location = new System.Drawing.Point(1188, 708);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(100, 46);
            this.BtnRegresar.TabIndex = 35;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = true;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // BtnNuevo
            // 
            this.BtnNuevo.Location = new System.Drawing.Point(764, 708);
            this.BtnNuevo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnNuevo.Name = "BtnNuevo";
            this.BtnNuevo.Size = new System.Drawing.Size(100, 39);
            this.BtnNuevo.TabIndex = 34;
            this.BtnNuevo.Text = "NUEVO";
            this.BtnNuevo.UseVisualStyleBackColor = true;
            this.BtnNuevo.Click += new System.EventHandler(this.BtnNuevo_Click);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Location = new System.Drawing.Point(553, 708);
            this.BtnEliminar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(100, 39);
            this.BtnEliminar.TabIndex = 33;
            this.BtnEliminar.Text = "ELIMINAR";
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // BtnEditar
            // 
            this.BtnEditar.Location = new System.Drawing.Point(376, 708);
            this.BtnEditar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(100, 39);
            this.BtnEditar.TabIndex = 32;
            this.BtnEditar.Text = "EDITAR";
            this.BtnEditar.UseVisualStyleBackColor = true;
            this.BtnEditar.Click += new System.EventHandler(this.BtnEditar_Click);
            // 
            // BtnAgregar
            // 
            this.BtnAgregar.Enabled = false;
            this.BtnAgregar.Location = new System.Drawing.Point(229, 708);
            this.BtnAgregar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnAgregar.Name = "BtnAgregar";
            this.BtnAgregar.Size = new System.Drawing.Size(100, 39);
            this.BtnAgregar.TabIndex = 31;
            this.BtnAgregar.Text = "AGREGAR";
            this.BtnAgregar.UseVisualStyleBackColor = true;
            this.BtnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(243, 538);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(731, 29);
            this.label23.TabIndex = 30;
            this.label23.Text = "TABLA CON LOS DATOS DEL VENDEDOR Y DEL VEHICULO";
            // 
            // Dgv1
            // 
            this.Dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15});
            this.Dgv1.Location = new System.Drawing.Point(28, 586);
            this.Dgv1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Dgv1.Name = "Dgv1";
            this.Dgv1.Size = new System.Drawing.Size(1260, 114);
            this.Dgv1.TabIndex = 29;
            this.Dgv1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv1_CellClick);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(944, 74);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 17);
            this.label21.TabIndex = 28;
            this.label21.Text = "VEHICULO";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.TxtTotal);
            this.groupBox4.Controls.Add(this.TxtImpuesto);
            this.groupBox4.Controls.Add(this.TxtPrecio);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Location = new System.Drawing.Point(28, 405);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(325, 113);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "VALOR A PAGAR";
            // 
            // TxtTotal
            // 
            this.TxtTotal.Enabled = false;
            this.TxtTotal.Location = new System.Drawing.Point(168, 76);
            this.TxtTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtTotal.Name = "TxtTotal";
            this.TxtTotal.Size = new System.Drawing.Size(132, 22);
            this.TxtTotal.TabIndex = 9;
            this.TxtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TxtImpuesto
            // 
            this.TxtImpuesto.Location = new System.Drawing.Point(168, 46);
            this.TxtImpuesto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtImpuesto.MaxLength = 2;
            this.TxtImpuesto.Name = "TxtImpuesto";
            this.TxtImpuesto.Size = new System.Drawing.Size(132, 22);
            this.TxtImpuesto.TabIndex = 8;
            this.TxtImpuesto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtImpuesto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtImpuesto_KeyPress);
            // 
            // TxtPrecio
            // 
            this.TxtPrecio.Location = new System.Drawing.Point(168, 16);
            this.TxtPrecio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtPrecio.MaxLength = 6;
            this.TxtPrecio.Name = "TxtPrecio";
            this.TxtPrecio.Size = new System.Drawing.Size(132, 22);
            this.TxtPrecio.TabIndex = 7;
            this.TxtPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtPrecio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtImpuesto_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 85);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(123, 17);
            this.label20.TabIndex = 6;
            this.label20.Text = "TOTAL A PAGAR:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 53);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 17);
            this.label18.TabIndex = 5;
            this.label18.Text = "IMPUESTO:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(301, 36);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 17);
            this.label22.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 25);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(63, 17);
            this.label19.TabIndex = 1;
            this.label19.Text = "PRECIO:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.TxtTelComp);
            this.groupBox3.Controls.Add(this.TxtCedComp);
            this.groupBox3.Controls.Add(this.TxtNomComp);
            this.groupBox3.Controls.Add(this.CboTelComp);
            this.groupBox3.Controls.Add(this.TxtDirComp);
            this.groupBox3.Controls.Add(this.TxtApeComp);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(28, 59);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(401, 326);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "DATOS DEL VENDEDOR";
            // 
            // TxtTelComp
            // 
            this.TxtTelComp.Location = new System.Drawing.Point(264, 277);
            this.TxtTelComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtTelComp.Name = "TxtTelComp";
            this.TxtTelComp.Size = new System.Drawing.Size(128, 22);
            this.TxtTelComp.TabIndex = 17;
            this.TxtTelComp.TextChanged += new System.EventHandler(this.TxtTelComp_TextChanged);
            this.TxtTelComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTelComp_KeyPress);
            // 
            // TxtCedComp
            // 
            this.TxtCedComp.Location = new System.Drawing.Point(139, 223);
            this.TxtCedComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtCedComp.MaxLength = 10;
            this.TxtCedComp.Name = "TxtCedComp";
            this.TxtCedComp.Size = new System.Drawing.Size(132, 22);
            this.TxtCedComp.TabIndex = 15;
            this.TxtCedComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtCedComp_KeyPress);
            // 
            // TxtNomComp
            // 
            this.TxtNomComp.Location = new System.Drawing.Point(139, 59);
            this.TxtNomComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtNomComp.MaxLength = 22;
            this.TxtNomComp.Name = "TxtNomComp";
            this.TxtNomComp.Size = new System.Drawing.Size(132, 22);
            this.TxtNomComp.TabIndex = 16;
            this.TxtNomComp.TextChanged += new System.EventHandler(this.TxtNomComp_TextChanged);
            this.TxtNomComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtNomComp_KeyPress);
            // 
            // CboTelComp
            // 
            this.CboTelComp.FormattingEnabled = true;
            this.CboTelComp.Items.AddRange(new object[] {
            "FIJO",
            "MOVIL"});
            this.CboTelComp.Location = new System.Drawing.Point(139, 276);
            this.CboTelComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CboTelComp.Name = "CboTelComp";
            this.CboTelComp.Size = new System.Drawing.Size(116, 24);
            this.CboTelComp.TabIndex = 12;
            this.CboTelComp.SelectedIndexChanged += new System.EventHandler(this.CboTelComp_SelectedIndexChanged);
            // 
            // TxtDirComp
            // 
            this.TxtDirComp.Location = new System.Drawing.Point(139, 170);
            this.TxtDirComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtDirComp.MaxLength = 22;
            this.TxtDirComp.Name = "TxtDirComp";
            this.TxtDirComp.Size = new System.Drawing.Size(132, 22);
            this.TxtDirComp.TabIndex = 12;
            this.TxtDirComp.TextChanged += new System.EventHandler(this.TxtDirComp_TextChanged);
            // 
            // TxtApeComp
            // 
            this.TxtApeComp.Location = new System.Drawing.Point(139, 114);
            this.TxtApeComp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtApeComp.MaxLength = 22;
            this.TxtApeComp.Name = "TxtApeComp";
            this.TxtApeComp.Size = new System.Drawing.Size(132, 22);
            this.TxtApeComp.TabIndex = 13;
            this.TxtApeComp.TextChanged += new System.EventHandler(this.TxtApeComp_TextChanged);
            this.TxtApeComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtNomComp_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 286);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "TELEFONO:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 231);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 17);
            this.label10.TabIndex = 9;
            this.label10.Text = "CEDULA:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 178);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "DIRECCIÓN:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 68);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "NOMBRE:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 123);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "APELLIDO:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TxtMatricula);
            this.groupBox2.Controls.Add(this.TxtColor);
            this.groupBox2.Controls.Add(this.CboCilindraje);
            this.groupBox2.Controls.Add(this.TxtAño);
            this.groupBox2.Controls.Add(this.CboTipo);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.CboMarca);
            this.groupBox2.Location = new System.Drawing.Point(457, 59);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(363, 369);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DATOS DEL VEHICULO";
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(135, 321);
            this.TxtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtMatricula.MaxLength = 7;
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(132, 22);
            this.TxtMatricula.TabIndex = 23;
            this.TxtMatricula.TextChanged += new System.EventHandler(this.TxtMatricula_TextChanged);
            // 
            // TxtColor
            // 
            this.TxtColor.Location = new System.Drawing.Point(135, 223);
            this.TxtColor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtColor.MaxLength = 10;
            this.TxtColor.Name = "TxtColor";
            this.TxtColor.Size = new System.Drawing.Size(132, 22);
            this.TxtColor.TabIndex = 22;
            this.TxtColor.TextChanged += new System.EventHandler(this.TxtColor_TextChanged);
            this.TxtColor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtColor_KeyPress);
            // 
            // CboCilindraje
            // 
            this.CboCilindraje.FormattingEnabled = true;
            this.CboCilindraje.Items.AddRange(new object[] {
            "1.2",
            "1.4",
            "1.6",
            "1.8",
            "2.0"});
            this.CboCilindraje.Location = new System.Drawing.Point(135, 276);
            this.CboCilindraje.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CboCilindraje.Name = "CboCilindraje";
            this.CboCilindraje.Size = new System.Drawing.Size(160, 24);
            this.CboCilindraje.TabIndex = 21;
            // 
            // TxtAño
            // 
            this.TxtAño.Location = new System.Drawing.Point(135, 175);
            this.TxtAño.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TxtAño.MaxLength = 4;
            this.TxtAño.Name = "TxtAño";
            this.TxtAño.Size = new System.Drawing.Size(132, 22);
            this.TxtAño.TabIndex = 20;
            this.TxtAño.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtAño_KeyPress);
            // 
            // CboTipo
            // 
            this.CboTipo.FormattingEnabled = true;
            this.CboTipo.Items.AddRange(new object[] {
            "SEDAN",
            "CAMIONETA"});
            this.CboTipo.Location = new System.Drawing.Point(135, 113);
            this.CboTipo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CboTipo.Name = "CboTipo";
            this.CboTipo.Size = new System.Drawing.Size(160, 24);
            this.CboTipo.TabIndex = 19;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 286);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 17);
            this.label17.TabIndex = 15;
            this.label17.Text = "CILINDRAJE:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 231);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 17);
            this.label16.TabIndex = 14;
            this.label16.Text = "COLOR";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 178);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 17);
            this.label15.TabIndex = 13;
            this.label15.Text = "AÑO:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 123);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 17);
            this.label14.TabIndex = 12;
            this.label14.Text = "TIPO:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 331);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 17);
            this.label12.TabIndex = 10;
            this.label12.Text = "N° MATRICULA:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 68);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 17);
            this.label13.TabIndex = 11;
            this.label13.Text = "MARCA:";
            // 
            // CboMarca
            // 
            this.CboMarca.FormattingEnabled = true;
            this.CboMarca.Items.AddRange(new object[] {
            "HYUNDAI",
            "CHEVROLET",
            "KIA",
            "NISSAN",
            "OTRO"});
            this.CboMarca.Location = new System.Drawing.Point(135, 68);
            this.CboMarca.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CboMarca.Name = "CboMarca";
            this.CboMarca.Size = new System.Drawing.Size(160, 24);
            this.CboMarca.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(401, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 29);
            this.label1.TabIndex = 23;
            this.label1.Text = "FORMULARIO DE COMPRA\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(840, 94);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(276, 256);
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(405, 456);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(149, 50);
            this.btnCalcular.TabIndex = 37;
            this.btnCalcular.Text = "CALCULAR";
            this.toolTip1.SetToolTip(this.btnCalcular, "PRESIONE PARA CALCULAR EL VALOR TOTAL A PAGAR....");
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "# venta";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "NOMBRE";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "APELLIDO";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "DIRECCION";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "CEDULA";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "TELEFONO";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "MARCA";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "TIPO";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "AÑO";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "COLOR";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "CILINDRAJE";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "MATRICULA";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "PRECIO";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.HeaderText = "VALR. IMPUESTO";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.HeaderText = "VALOR TOTAL";
            this.Column15.Name = "Column15";
            // 
            // Compra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1315, 761);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.BtnElegir);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.BtnNuevo);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.BtnEditar);
            this.Controls.Add(this.BtnAgregar);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.Dgv1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Compra";
            this.ShowIcon = false;
            this.Text = "Compra";
            ((System.ComponentModel.ISupportInitialize)(this.Dgv1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnElegir;
        private System.Windows.Forms.Button BtnRegresar;
        private System.Windows.Forms.Button BtnNuevo;
        private System.Windows.Forms.Button BtnEliminar;
        private System.Windows.Forms.Button BtnEditar;
        private System.Windows.Forms.Button BtnAgregar;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView Dgv1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox TxtTotal;
        private System.Windows.Forms.TextBox TxtImpuesto;
        private System.Windows.Forms.TextBox TxtPrecio;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TxtTelComp;
        private System.Windows.Forms.TextBox TxtCedComp;
        private System.Windows.Forms.TextBox TxtNomComp;
        private System.Windows.Forms.ComboBox CboTelComp;
        private System.Windows.Forms.TextBox TxtDirComp;
        private System.Windows.Forms.TextBox TxtApeComp;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.TextBox TxtColor;
        private System.Windows.Forms.ComboBox CboCilindraje;
        private System.Windows.Forms.TextBox TxtAño;
        private System.Windows.Forms.ComboBox CboTipo;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox CboMarca;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
    }
}